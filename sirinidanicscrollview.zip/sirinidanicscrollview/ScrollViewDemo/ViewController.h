//
//  ViewController.h
//  ScrollViewDemo
//
//  Created by indianic on 10/06/16.
//  Copyright © 2016 IndiaNIC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
    IBOutlet UIScrollView *scrollview;
    
    IBOutlet UIPageControl *pageCntrl;
    
    NSMutableArray *arrMutimg;
}
//- (IBAction)clickPage:(id)sender;

@end

