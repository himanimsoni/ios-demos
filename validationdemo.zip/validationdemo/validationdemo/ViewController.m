//
//  ViewController.m
//  validationdemo
//
//  Created by indianic on 14/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){

    NSString *reg;

}

@end

@implementation ViewController

- (BOOL) validatePhone: (NSString *) candidate {
    NSString *phoneRegex = @"[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    
    return [phoneTest evaluateWithObject:candidate];
}

- (BOOL) validateEmail: (NSString *) candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}

-(BOOL) validateName: (NSString *) candidate {
    
    NSString *nameRegex = @"^.{3,10}$";
    NSPredicate *nameTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    
    return [nameTest evaluateWithObject:candidate];
    
}


-(BOOL)isValidPassword:(NSString *)passwordString
{
    NSString *stricterFilterString = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[$@$!%*?&])[A-Za-z\\d$@$!%*?&]{10,}";
    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", stricterFilterString];
    return [passwordTest evaluateWithObject:passwordString];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    _imgError.hidden = true;
    _lblNameErMsg.hidden=true;
    
    _imgEmailErr.hidden = true;
    _lblEmail.hidden=true;

    _imgPhoneErr.hidden = true;
    _lblPhone.hidden=true;
    
    _imgPasswordErr.hidden = true;
    _lblPassword.hidden=true;


    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    if(textField == _textName){
    _imgError.hidden = true;
    _lblNameErMsg.hidden=true;
    }
    
    else if (textField == _textEmail){
        _imgEmailErr.hidden = true;
        _lblEmail.hidden=true;

    
    }
    
    else if (textField == _textPhone){
        _imgPhoneErr.hidden = true;
        _lblPhone.hidden=true;
        
        
    }
    
    else if (textField == _textPassword){
        _imgPasswordErr.hidden = true;
        _lblPassword.hidden=true;
        
        
    }
    
}

- (IBAction)btnCheck:(UIButton *)sender {
    
    
    
    if([self validateName:_textName.text]== false){
        _imgError.hidden = false;
        _lblNameErMsg.hidden=false;
        _lblNameErMsg.text = @"Invalid- length should be between 3-10";
        
        
    }
    
    if([self validateEmail:_textEmail.text]== false){
        _imgEmailErr.hidden = false;
        _lblEmail.hidden=false;
        _lblEmail.text = @"Invalid Email Format";
        
    }
    
    if([self validatePhone:_textPhone.text]== false){
        _imgPhoneErr.hidden = false;
        _lblPhone.hidden=false;
        _lblPhone.text = @"Invalid- follow /n xxx-xxx-xxxx /n format";
        
    }

    if([self isValidPassword:_textPassword.text]== false){
        _imgPasswordErr.hidden = false;
        _lblPassword.hidden=false;
        _lblPassword.text = @"Invalid- min 10 /n character length /n with atleast 1 /n uppercase,lowercase /n & specialcharacter";
        
    }
    
    [self.view endEditing:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([textField isEqual:_textName]) {
        [_textEmail becomeFirstResponder];
    }
    if ([textField isEqual:_textEmail]) {
        [_textPhone becomeFirstResponder];
    }
    if ([textField isEqual:_textPhone]) {
        [_textPassword becomeFirstResponder];
    }
    if ([textField isEqual:_textPassword]) {
        [textField resignFirstResponder];
    }
    return YES;
}

@end
