//
//  ViewController.h
//  validationdemo
//
//  Created by indianic on 14/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *textName;
@property (strong, nonatomic) IBOutlet UIImageView *imgError;
@property (strong, nonatomic) IBOutlet UILabel *lblNameErMsg;
@property (strong, nonatomic) IBOutlet UITextField *textEmail;
@property (strong, nonatomic) IBOutlet UIImageView *imgEmailErr;
@property (strong, nonatomic) IBOutlet UILabel *lblEmail;
@property (strong, nonatomic) IBOutlet UITextField *textPhone;
@property (strong, nonatomic) IBOutlet UIImageView *imgPhoneErr;
@property (strong, nonatomic) IBOutlet UILabel *lblPhone;
@property (strong, nonatomic) IBOutlet UITextField *textPassword;
@property (strong, nonatomic) IBOutlet UIImageView *imgPasswordErr;
@property (strong, nonatomic) IBOutlet UILabel *lblPassword;

@end

