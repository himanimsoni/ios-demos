//
//  ViewController.m
//  delegatedemo
//
//  Created by indianic on 11/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self  btnSendbysegue:nil];   to click button manually
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnSendbysegue:(id)sender {
    
    dictionary = [NSDictionary dictionaryWithObjects: @[_txtName.text, _textMarks.text, _textStd.text] forKeys: @[@"mname", @"mmarks", @"mstd"]];
    
    [self performSegueWithIdentifier:@"segudirectpush" sender:sender];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if([segue.identifier isEqualToString:@"segudirectpush"]){
        
        SecondVC *objSecVc = [segue destinationViewController];
        objSecVc.dicobj = dictionary;
        
//        objSecVc.strName = _txtName.text;
//        objSecVc.strMarks = _textMarks.text;
//        objSecVc.strStd = _textStd.text;
//        
//        NSLog(@"%@ name from main", _txtName);
    }

}



@end
