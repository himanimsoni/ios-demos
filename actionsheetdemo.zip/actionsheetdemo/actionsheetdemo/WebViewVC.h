//
//  WebViewVC.h
//  actionsheetdemo
//
//  Created by indianic on 10/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewVC : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *WebView;
@property (strong) UIImage *image;
@property (weak) NSString *urlstring;
@property (weak, nonatomic) IBOutlet UIImageView *imageOutlet;

@end
