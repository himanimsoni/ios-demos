//
//  ViewController.h
//  reversedatapasing
//
//  Created by indianic on 15/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol data <NSObject>

-(void)updateData:(NSDictionary *)dic;

@end

@interface ViewController : UIViewController <UITextFieldDelegate,UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UITextField *textName;
@property (strong, nonatomic) IBOutlet UITextField *textEmail;
@property (strong, nonatomic) IBOutlet UITextField *textPhone;
@property (strong, nonatomic) IBOutlet UITextField *textPass;
@property (strong,nonatomic) id <data> delegate;
@property (strong, nonatomic) IBOutlet UITextView *textAdd;


@end

