//
//  SecondViewController.m
//  reversedatapasing
//
//  Created by indianic on 16/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)updateData:(NSDictionary *)dic{
    
    _lblName.text = [dic valueForKey:@"name"];
    _lblEmail.text = [dic valueForKey:@"email"];
    _lblPhone.text = [dic valueForKey:@"phone"];
    _lblPass.text = [dic valueForKey:@"pass"];
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if([segue.identifier isEqualToString:@"seguecall"]){
    
        ViewController *obj = segue.destinationViewController;
        obj.delegate = self;
    }
 
}


@end
