//
//  ViewController.m
//  reversedatapasing
//
//  Created by indianic on 15/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
 
    NSDictionary *dictionary;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnButton:(UIButton *)sender {
    
    dictionary = [NSDictionary dictionaryWithObjects:@[_textName.text, _textEmail.text, _textPhone.text, _textPass.text] forKeys:@[@"name", @"email", @"phone", @"pass"]];
    [_delegate updateData:dictionary];
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if ([textField isEqual:_textName]) {
        [_textEmail becomeFirstResponder];
    }
    if ([textField isEqual:_textEmail]) {
        [_textPhone becomeFirstResponder];
    }
    if ([textField isEqual:_textPhone]) {
        [_textPass becomeFirstResponder];
    }
    if ([textField isEqual:_textPass]) {
        [_textAdd becomeFirstResponder];
    }
   
    return YES;
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [_scroll setContentOffset:CGPointMake(0, _textAdd.frame.origin.y+200 )];
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{

    
    [_scroll setContentOffset:CGPointMake(0, _textAdd.frame.origin.y-200 )];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqual:@"\n"]) {
        [textView resignFirstResponder];
    }
    return true;
}

@end
