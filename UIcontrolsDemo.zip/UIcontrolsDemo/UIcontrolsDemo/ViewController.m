//
//  ViewController.m
//  UIcontrolsDemo
//
//  Created by indianic on 08/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"
#import "InfoVC.h"
#include "webViewVc.h"
@interface ViewController () 
{
    NSString *gen;
    NSString *person;
     NSString *url;
    int errorflag;
    
    
    UIAlertView *alert;
    NSString *errorString;
    
        
}
@end

@implementation ViewController

-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    errorflag=0;
    errorString=@"";
    
//    _imgProfilepic.layer.cornerRadius =39;
//    _imgProfilepic.layer.masksToBounds=true;
    
    _sliderAge.maximumValue=100;
    _sliderAge.minimumValue=18;
    
    _textAddress.layer.borderWidth=2;
    _textAddress.layer.borderColor= [UIColor lightGrayColor].CGColor ;
    person=[_segPerson titleForSegmentAtIndex:0];
    
    alert=[[UIAlertView alloc]initWithTitle:@"Warning" message:@"" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:@"Ok", nil];
    
    bool jhfj =[self NSStringIsValidEmail:@"himanibloom@gmail.com"];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)textViewDidBeginEditing:(UITextView *)textView{
    _textAddress.text=@"" ;


    
}


- (IBAction)BtnSignUp:(UIButton *)sender {
   
    if ([self validateform]) {
        [self performSegueWithIdentifier:@"seguInfo" sender:sender];
    }
    
    
    
}


-(bool)validateform{
   
    if (_textName.text.length <8 ) {
        _textName.layer.backgroundColor=[UIColor redColor].CGColor;
        errorString=[NSString stringWithFormat:@"%@%@",errorString,@"please enter name "];
        errorflag++;
        
    }
    else{
         _textName.layer.backgroundColor=[UIColor clearColor].CGColor;
    }
    if (_textEmail.text.length <8 ) {
        _textEmail.layer.backgroundColor=[UIColor redColor].CGColor;
        errorString=[NSString stringWithFormat:@"%@%@",errorString,@"\n please enter email "];
          errorflag++;
        
    }
    else{
        _textEmail.layer.backgroundColor=[UIColor clearColor].CGColor;

    }
    if (_textAddress.text.length <8 ) {
         errorString=[NSString stringWithFormat:@"%@%@",errorString,@"\n please enter address "];
        _textAddress.layer.borderColor=[UIColor redColor].CGColor;
          errorflag++;
        
    }else{
        _textAddress.layer.borderColor=[UIColor grayColor].CGColor;
    }
//    NSLog(@"error =%@",errorString);
    
    
   
        if (errorflag==0) {
           
            
            return true;
        }
    if (errorflag!=0) {
        alert.message=errorString;
        [alert show];
        errorString=@"";
        errorflag=0;

        return false;
    }
    

    return false;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if ([textField isEqual:_textName]) {
        [_textEmail becomeFirstResponder];
    }
    else if ([textField isEqual:_textEmail]) {
       [_textAddress becomeFirstResponder];
    }
//    else if ([textField isEqual:_textAddress]){
//        [textField resignFirstResponder];
//    }
    return YES;
}


- (BOOL)textView:(UITextView *)textView
shouldChangeTextInRange:(NSRange)range
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
    }
    return YES;
}


- (IBAction)sliderAge:(UISlider *)sender {
    
    _lblAge.text=[NSString stringWithFormat:@"%.0f",_sliderAge.value];
}
- (IBAction)segType:(UISegmentedControl *)sender {
    
    person=[_segPerson titleForSegmentAtIndex:sender.selectedSegmentIndex];
}



-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if([segue.identifier isEqualToString:@"seguInfo"]){
        NSLog(@"Segu info called");
        NSLog(@"name  : %@",_textName.text);
        NSLog(@"email  : %@",_textEmail.text);
        NSLog(@"address : %@",_textAddress.text);
        
        if( _gender.isOn){
            NSLog(@"gender : female");
            gen=@"Female";
        }
        else{
            NSLog(@"gender : male");
            gen=@"Male";
        }
        NSLog(@"age : %@",_lblAge.text);
        NSLog(@"type :  %@ ",person);
        

        InfoVC *objInfoVC = [segue destinationViewController] ;
        
        objInfoVC.strName=_textName.text;
        objInfoVC.strEmail=_textEmail.text;
        objInfoVC.strAdd=_textAddress.text;
        objInfoVC.strGender=gen;
        objInfoVC.strAge=_lblAge.text;
        objInfoVC.strType=person;
        
        
    }
    
    else if ([segue.identifier isEqualToString:@"sagueWeb"]){
        webViewVc *objweb=[segue destinationViewController];
        objweb.urlstring=url;
    }
}
- (IBAction)btnGo:(UIButton *)sender {
    url=_textUrl.text;
    [self performSegueWithIdentifier:@"sagueWeb" sender:sender];
    
  
    
  
}

@end
