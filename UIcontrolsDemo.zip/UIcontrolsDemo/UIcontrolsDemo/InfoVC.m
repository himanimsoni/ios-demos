//
//  InfoVC.m
//  UIcontrolsDemo
//
//  Created by indianic on 08/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "InfoVC.h"
#import "ViewController.h"
#import "ShareViewVC.h"
@interface InfoVC (){
    
    UIAlertView *alert1;
    NSString *url1;
    UIActionSheet *actionsheet;

}

@end

@implementation InfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setData];
    NSLog(@"%@",_strName);
    
    
    actionsheet =[[UIActionSheet alloc]initWithTitle:@"Delete" delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:@"Share on Facebook",@"Share on Twitter",@"Share via E-mail",@"Save to Camera Roll", nil];
    
    alert1 =[[UIAlertView alloc]initWithTitle:@"Alert" message:@" This photo has been saved to your device" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    

}
- (IBAction)btnShare:(UIButton *)sender {
    
    [actionsheet showInView:self.view];
    
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    ShareViewVC *objweb=[segue destinationViewController];
    objweb.urlstring=url1;
    
}



- (void)actionSheet:(UIActionSheet *)popup clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    
    switch (buttonIndex) {
        case 0:
            NSLog(@"button clicked %@ ",[popup buttonTitleAtIndex:0]);
            
            url1= @"http://www.facebook.com";
            
            [self performSegueWithIdentifier:@"segutourl" sender:nil];
            
            break;
        case 1:
            url1= @"http://www.twitter.com";
            [self performSegueWithIdentifier:@"segutourl" sender:nil];
            break;
        case 2:
            url1= @"http://www.gmail.com";
            [self performSegueWithIdentifier:@"segutourl" sender:nil];
            break;
        case 3:
            [alert1 show];
            
            break;
    }
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)setData{
    
    _Name.text = _strName;
    _Email.text=_strEmail;
    _Addr.text = _strAdd;
    _Type.text=_strType;
    _Age.text=_strAge;
    _Gender.text = _strGender;
}

@end
