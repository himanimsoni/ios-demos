//
//  ViewController.h
//  UIcontrolsDemo
//
//  Created by indianic on 08/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate,UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imgProfilepic;


@property (weak, nonatomic) IBOutlet UITextField *textName;

@property (weak, nonatomic) IBOutlet UITextField *textEmail;

@property (weak, nonatomic) IBOutlet UITextView *textAddress;

@property (weak, nonatomic) IBOutlet UISwitch *gender;

@property (weak, nonatomic) IBOutlet UISlider *sliderAge;

@property (weak, nonatomic) IBOutlet UILabel *lblAge;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segPerson;

@property (weak, nonatomic) IBOutlet UITextField *textUrl;

-(bool)validateform;

@end

