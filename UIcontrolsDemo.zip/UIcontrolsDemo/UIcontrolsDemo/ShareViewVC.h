//
//  ShareViewVC.h
//  UIcontrolsDemo
//
//  Created by indianic on 10/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareViewVC : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@property (weak) NSString *urlstring;

@end
