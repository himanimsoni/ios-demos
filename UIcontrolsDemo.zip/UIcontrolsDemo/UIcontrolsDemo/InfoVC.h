//
//  InfoVC.h
//  UIcontrolsDemo
//
//  Created by indianic on 08/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoVC : UIViewController <UIActionSheetDelegate>

@property (strong,nonatomic) NSString *strName;
@property (strong,nonatomic) NSString *strEmail;
@property (strong,nonatomic) NSString *strAdd;
@property (strong,nonatomic) NSString *strAge;
@property (strong,nonatomic) NSString *strGender;
@property (strong,nonatomic) NSString *strType;


@property (weak, nonatomic) IBOutlet UILabel *Name;
@property (weak, nonatomic) IBOutlet UILabel *Email;
@property (weak, nonatomic) IBOutlet UILabel *Addr;

@property (weak, nonatomic) IBOutlet UILabel *Gender;
@property (weak, nonatomic) IBOutlet UILabel *Age;
@property (weak, nonatomic) IBOutlet UILabel *Type;

@end
