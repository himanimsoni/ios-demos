//
//  webViewVc.h
//  UIcontrolsDemo
//
//  Created by indianic on 09/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface webViewVc : UIViewController <UIWebViewDelegate>


@property (weak, nonatomic) IBOutlet UIWebView *webView;


@property (weak) NSString *urlstring;


@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *spinner;



@end
