//
//  ViewController.m
//  delegatedemowithbutton
//
//  Created by indianic on 11/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnclick:(UIButton *)sender {
    
    NSLog(@"%@", _txtName);
    
    if(_txtName.text.length != 0)
    {
    
        [self performSegueWithIdentifier:@"segudirectpush" sender:sender];
    
    }
    
    
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    
    if(_txtName.text.length == 0)
    {
    
    if([segue.identifier isEqualToString:@"segudirectpush"]){
        
        SecondVC *objSecVc = [segue destinationViewController];
        objSecVc.strName = _txtName.text;
        objSecVc.strMarks = _textMarks.text;
        objSecVc.strStd = _textStd.text;
        
        NSLog(@"%@ name from main", _txtName);
    }
    }
    
}

- (IBAction)btnSend:(id)sender {
    
//    [self performSegueWithIdentifier:@"segudirectpush" sender:sender];
}

@end
