//
//  SecondVC.h
//  delegatedemowithbutton
//
//  Created by indianic on 11/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondVC : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblMarks;
@property (weak, nonatomic) IBOutlet UILabel *lblStd;

@property (strong,nonatomic) NSString *strName;
@property (strong,nonatomic) NSString *strMarks;
@property (strong,nonatomic) NSString *strStd;

@end
