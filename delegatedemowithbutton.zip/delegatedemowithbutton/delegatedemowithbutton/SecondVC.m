//
//  SecondVC.m
//  delegatedemowithbutton
//
//  Created by indianic on 11/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "SecondVC.h"

@interface SecondVC ()

@end

@implementation SecondVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _lblName.text= _strName;
    _lblMarks.text = _strMarks;
    _lblStd.text = _strStd;
    
    
    NSLog(@" name from pused segue %@  %@", _strName,_strStd);
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
