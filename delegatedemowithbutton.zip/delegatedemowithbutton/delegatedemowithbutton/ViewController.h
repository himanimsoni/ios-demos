//
//  ViewController.h
//  delegatedemowithbutton
//
//  Created by indianic on 11/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondVC.h"
@interface ViewController : UIViewController<UITextViewDelegate,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *textMarks;

@property (weak, nonatomic) IBOutlet UITextField *textStd;

@end

