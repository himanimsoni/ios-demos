//
//  ViewController.m
//  teableiewdemo
//
//  Created by indianic on 15/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tabArray = [[NSMutableArray alloc]init];
    
    for(int i=0;i<10;i++){
        [tabArray addObject:[NSString stringWithFormat:@" Indexed number is %d", i]];
    }
  
    _tableView.editing = false;
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)tableView: (UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return tabArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *aCell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    aCell.textLabel.text = tabArray[indexPath.row];
   
    return aCell;
}


//- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    
//         return @"This is header";
//    }
//

//- (nullable NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
//   
//     return @"This is footer";
//}
//
//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//
//    return 50.0;
//}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{

    UIView *footerview = [[UIView alloc] initWithFrame:CGRectMake(0, 0,tableView.frame.size.width, 40)];
    footerview.backgroundColor = [UIColor blueColor];
  
    footerview.layer.cornerRadius = 10.0f;
     UILabel *label = [[UILabel alloc] initWithFrame:footerview.frame];
    if(section == 0){
        label.text = @"This is footer1";
    }
    else
    {
        label.text = @"This is footer2";
        
    }

    label.textColor = [UIColor whiteColor];
//    label.layer.cornerRadius = 20.0f;
//    label.layer.borderColor = [UIColor grayColor].CGColor;
//    label.layer.borderWidth = 3.0f;
     [footerview addSubview:label];
        return footerview;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 2;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *headerview = [[UIView alloc] initWithFrame:CGRectMake(0, 0,tableView.frame.size.width, 30)];
    headerview.backgroundColor = [UIColor greenColor];
    
        
    UILabel *label = [[UILabel alloc] initWithFrame:headerview.frame];
    if(section == 0){
    label.text = @"This is header1";
    }
    else
    {
        label.text = @"This is header2";
 
    }
    label.textColor = [UIColor whiteColor];
    [headerview addSubview:label];
    return headerview;
}


//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
//{
//    NSString *sectionName;
//    
//    switch (section)
//    {
//        case 0:
//            sectionName = @"myFirstSectionName";
//            break;
//        case 1:
//            sectionName = @"myOtherSectionName";
//            break;
//          }
//    return sectionName;
//}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return true;
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{

    NSInteger deletRow = indexPath.row;
    [tabArray removeObjectAtIndex:deletRow];
    [tableView reloadData];
}


- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return true;
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    
    NSString *stringToMove = tabArray[sourceIndexPath.row];
    [tabArray removeObjectAtIndex:sourceIndexPath.row];
    [tabArray insertObject:stringToMove atIndex:destinationIndexPath.row];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
   SecondViewController *obj =[self.storyboard instantiateViewControllerWithIdentifier:@"SecondViewController"];
    [self.navigationController pushViewController:obj animated:true];

   }

@end
