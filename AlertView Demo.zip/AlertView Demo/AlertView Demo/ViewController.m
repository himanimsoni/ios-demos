//
//  ViewController.m
//  AlertView Demo
//
//  Created by indianic1 on 09/06/16.
//  Copyright © 2016 IndiaNIC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIAlertViewDelegate>
{
    UIAlertView *firstAlert;
    UIAlertView *secondAlert;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnClick:(id)sender {
    
    UIButton *btn = (UIButton *)sender;
    NSInteger tagValue = [btn tag];
    
    if (tagValue == 10) {
        
//        firstAlert  = [[UIAlertView alloc]initWithTitle:@"Alert Title" message:@"Successfully LOgin" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
//        [firstAlert show];
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"ALertview" message:@"Alert Message" preferredStyle:UIAlertControllerStyleAlert];
        
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        
        UIAlertAction *actionOK = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertController addAction:actionCancel];
        [alertController addAction:actionOK];
        
        [self presentViewController:alertController animated:YES completion:^{
            
        }];
    }
    else if (tagValue == 11) {
        
//        secondAlert = [[UIAlertView alloc]initWithTitle:@"Second Alert Title" message:@"Successfully LOgin" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
//        [secondAlert show];
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"Action Sheet" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Button1" otherButtonTitles:@"Button2",@"Button 3",@"BUtton 4", nil];
        
        [actionSheet showInView:self.view];

    }
//    if ([btn isKindOfClass:[UIButton class]]) {
//        
//    }
    
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"Action Sheet" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Button1" otherButtonTitles:@"Button2",@"Button 3",@"BUtton 4", nil];
    
//    [actionSheet showInView:actionSheet];
    
    
}

 -(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if ([firstAlert isEqual:alertView]) {
    
        if (buttonIndex == 0) {
            NSLog(@"Cancel Button Pressed");
        }
        else if (buttonIndex == 1) {
            
            NSLog(@"Ok Button Pressed");
        }
    }
    else if ([secondAlert isEqual:alertView]) {
        
        if (buttonIndex == 0) {
            NSLog(@"second Cancel Button Pressed");
        }
        else if (buttonIndex == 1) {
            
            NSLog(@"Second Ok Button Pressed");
        }
    }
    
    
    
}

@end
