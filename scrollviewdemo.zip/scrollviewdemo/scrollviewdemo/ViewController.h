//
//  ViewController.h
//  scrollviewdemo
//
//  Created by indianic on 10/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableArray *arrimg;
}
@property (weak, nonatomic) IBOutlet UISlider *sliderStd;
@property (weak, nonatomic) IBOutlet UILabel *lblStd;
@property (weak, nonatomic) IBOutlet UITextField *textName;
@property (weak, nonatomic) IBOutlet UITextField *textAge;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segGender;
@property (weak, nonatomic) IBOutlet UITextField *textMarks;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UIScrollView *imagescrollview;
@property (weak, nonatomic) IBOutlet UIPageControl *pgcontroller;


@end

