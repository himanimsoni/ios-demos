//
//  ViewController.m
//  scrollviewdemo
//
//  Created by indianic on 10/06/16.
//  Copyright © 2016 indianic. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *scrolloutlet;

@end

@implementation ViewController
NSString *person;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    _imagescrollview.layer.cornerRadius = 8.0;
    _scrollview.layer.cornerRadius = 6.0;
    _scrollview.layer.borderWidth= 2.0;
    _scrollview.layer.borderColor=[UIColor colorWithRed:1 green:0 blue:0 alpha:0.5].CGColor;
    self.view.backgroundColor = [UIColor blueColor];

//    _scrollview.layer.opacity=0.5;
    

    _sliderStd.maximumValue=4;
    _sliderStd.minimumValue=1;
    
    _scrollview.contentSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height);
    
    arrimg = [[NSMutableArray alloc]initWithObjects: @"himani.png",@"2ndpic.png",@"3rdimg.png",@"4thimg.png", nil];
    
    for(int i=0; i<arrimg.count; i++){
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(_imagescrollview.frame.size.width*i , 0, _imagescrollview.frame.size.width, _imagescrollview.frame.size.height)];
        
        [imageView setImage: [UIImage imageNamed:arrimg[i]]];
        
        [_imagescrollview addSubview:imageView];
    
    }
    
  _imagescrollview.contentSize = CGSizeMake(_imagescrollview.frame.size.width*arrimg.count, _imagescrollview.frame.size.height);
    _pgcontroller.numberOfPages = arrimg.count;
    
    _scrollview.contentSize =CGSizeMake(self.view.frame.size.width,self.view.frame.size.height - 250);
    
    [_imagescrollview setContentOffset:CGPointMake(_imagescrollview.frame.size.width*2 ,0)];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)sliderStd:(id)sender {
    _lblStd.text=[NSString stringWithFormat:@"%.0f",_sliderStd.value];
    
}
- (IBAction)actiongender:(UISegmentedControl *)sender {
    
     person=[_segGender titleForSegmentAtIndex:sender.selectedSegmentIndex];
}

- (IBAction)btnSubmit:(id)sender {
    
    NSLog(@"Name:   %@", _textName.text);
    NSLog(@"Age:  %@", _textAge.text);
    
    NSLog(@"Gender  %@", person);
    NSLog(@"Std:   %@", _lblStd.text);
    NSLog(@"Marks:  %@", _textMarks.text);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    CGFloat pagewidth =scrollView.bounds.size.width;
    NSInteger pageNumber = floor((scrollView.contentOffset.x - pagewidth/2) / pagewidth)+1;
    _pgcontroller.currentPage = pageNumber;
}

@end
